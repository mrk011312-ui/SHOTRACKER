
const $=id=>document.getElementById(id);
const video=$('video'),canvas=$('overlay'),ctx=canvas.getContext('2d');
const startBtn=$('start'),calBtn=$('calibrate');
const statusEl=$('status'),live=$('liveBadge'),badge=$('modelBadge'),aiBadge=$('aiBadge');
let model=null,stream=null,running=false,aiLoading=false,aiReady=false,calibrating=false,draggingHoop=false;
let hoop=null,hoopLocked=false,hoopHint=null,hoopConfidence=0,stableRimFrames=0,rimCandidates=[],rimScanCanvas=document.createElement('canvas'),rimScanCtx=rimScanCanvas.getContext('2d');
let warmupAttempts=0,warmupConfirmed=0,lastRimScan=0;
let ballTrack=null,ballTrail=[],shotState=null,lastInfer=0,inferBusy=false,frameSeq=0;
let shots=[];
const MIN_WARMUPS=3,CONFIRM_WARMUPS=5,MAX_WARMUPS=12,MIN_RIM_CONF=84;
const rfKeyEl=$('rfKey'),rfSave=$('rfSave'),rfStatus=$('rfStatus');
const RF_MODEL='basketball-1zhpe-8qwvy',RF_VERSION='1';
let rfKey=localStorage.getItem('rf_publishable_key')||'',rfLoading=false,rfReady=false,rfEngine=null,rfWorker=null,RFInferenceEngine=null,RFCVImage=null;
function setStatus(x){statusEl.innerHTML=x}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function resize(){canvas.width=video.videoWidth||1280;canvas.height=video.videoHeight||720;if(hoop)hoop=normalizeHoop(hoop)}
video.addEventListener('loadedmetadata',resize);
function normalizeHoop(h){return {x:clamp(h.x,0,canvas.width),y:clamp(h.y,0,canvas.height),rx:clamp(h.rx||canvas.width*.07,24,canvas.width*.18),ry:clamp(h.ry||canvas.height*.025,10,canvas.height*.08)}}
function saveHoop(){if(hoop)localStorage.setItem('shotTrackerHoopV6',JSON.stringify(hoop))}
function loadHoop(){try{const h=JSON.parse(localStorage.getItem('shotTrackerHoopV6'));if(h&&Number.isFinite(h.x)&&Number.isFinite(h.y)){hoopHint=normalizeHoop(h);return true}}catch(e){}return false}
function resetTrackingState(){ballTrack=null;ballTrail=[];shotState=null;hoopLocked=false;hoop=null;hoopConfidence=0;stableRimFrames=0;rimCandidates=[];warmupAttempts=0;warmupConfirmed=0;lastRimScan=0;frameSeq=0;hoopHint=null}
function renderStats(){const makes=shots.filter(s=>s.make).length,n=shots.length;$('shots').textContent=n;$('makes').textContent=makes;$('fg').textContent=n?Math.round(makes/n*100)+'%':'0%';let st=0;for(let i=n-1;i>=0&&shots[i].make;i--)st++;$('streak').textContent=st;$('log').innerHTML=n?shots.slice().reverse().slice(0,15).map(s=>`<div class="shot"><span>${s.make?'✅ Make':'❌ Miss'} · ${s.auto?'Auto':'Manual'}</span><span>${s.time}</span></div>`).join(''):'<div class="note" style="padding-top:10px">No shots yet.</div>'}
function addShot(make,auto=true){shots.push({make,auto,time:new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit',second:'2-digit'})});renderStats()}
function draw(){if(!running)return;ctx.clearRect(0,0,canvas.width,canvas.height);if(hoop){ctx.strokeStyle=hoopLocked?'#9ff0bb':'#ffd166';ctx.lineWidth=6;ctx.beginPath();ctx.ellipse(hoop.x,hoop.y,hoop.rx,hoop.ry,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle=hoopLocked?'#9ff0bb':'#ffd166';ctx.font='bold 17px system-ui';ctx.fillText(hoopLocked?'RIM LOCKED':'RIM CANDIDATE',hoop.x-45,hoop.y-hoop.ry-10);ctx.beginPath();ctx.arc(hoop.x,hoop.y,7,0,Math.PI*2);ctx.fill()}if(ballTrail.length>1){ctx.strokeStyle='#fff';ctx.globalAlpha=.55;ctx.lineWidth=3;ctx.beginPath();ballTrail.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.globalAlpha=1}requestAnimationFrame(draw)}
function updateBadges(){aiBadge.textContent=`Rim: ${hoopLocked?'locked '+Math.round(hoopConfidence)+'%':hoop?'candidate '+Math.round(hoopConfidence)+'%':'searching'}`;badge.textContent=aiReady?'AI ready':'AI '+(aiLoading?'loading…':'idle')}
function warmupStatus(){if(hoopLocked)setStatus('🎯 <strong>Rim locked.</strong> Keep shooting — makes and misses are now counted automatically.');else setStatus(`🔥 <strong>Warm-up ${Math.min(warmupAttempts,MAX_WARMUPS)}/${CONFIRM_WARMUPS}</strong> — shoot naturally. The AI needs repeated rim evidence and a valid ball trajectory before locking.`);updateBadges()}
function rimLockedEnough(){return warmupAttempts>=MIN_WARMUPS&&warmupConfirmed>=MIN_WARMUPS&&hoopConfidence>=MIN_RIM_CONF&&stableRimFrames>=10}
function maybeLockRim(){if(hoopLocked||!hoop)return;if(rimLockedEnough()){hoopLocked=true;saveHoop();live.textContent='AI tracking';warmupStatus()}}
function recordWarmupAttempt(){if(hoopLocked)return;warmupAttempts++;if(hoop&&hoopConfidence>=MIN_RIM_CONF&&stableRimFrames>=10){warmupConfirmed++;}if(warmupAttempts>=MAX_WARMUPS&&!rimLockedEnough()){setStatus('⚠️ <strong>Rim not confidently confirmed.</strong> Keep the hoop fully visible, avoid rapid camera movement, or use Manual Hoop Fallback.');return}maybeLockRim();if(!hoopLocked)warmupStatus()}
function candidateFromImage(){const sw=360,sh=Math.max(200,Math.round(sw*canvas.height/canvas.width));rimScanCanvas.width=sw;rimScanCanvas.height=sh;rimScanCtx.drawImage(video,0,0,sw,sh);const d=rimScanCtx.getImageData(0,0,sw,sh).data,step=3,seen=new Uint8Array(sw*sh),comps=[];for(let y=Math.floor(sh*.05);y<Math.floor(sh*.9);y+=step)for(let x=0;x<sw;x+=step){const i=(y*sw+x)*4,r=d[i],g=d[i+1],b=d[i+2],mx=Math.max(r,g,b),mn=Math.min(r,g,b);const warm=r>110&&r>g*1.14&&g>b*1.08&&mx-mn>32;if(warm)seen[y*sw+x]=1}const dirs=[[step,0],[-step,0],[0,step],[0,-step],[step,step],[-step,-step],[step,-step],[-step,step]];for(let y=Math.floor(sh*.05);y<Math.floor(sh*.9);y+=step)for(let x=0;x<sw;x+=step){const idx=y*sw+x;if(!seen[idx])continue;const q=[[x,y]];seen[idx]=0;let n=0,sx=0,sy=0,minX=x,maxX=x,minY=y,maxY=y;while(q.length){const [cx,cy]=q.pop();n++;sx+=cx;sy+=cy;minX=Math.min(minX,cx);maxX=Math.max(maxX,cx);minY=Math.min(minY,cy);maxY=Math.max(maxY,cy);for(const [dx,dy] of dirs){const nx=cx+dx,ny=cy+dy;if(nx>=0&&nx<sw&&ny>=0&&ny<sh&&seen[ny*sw+nx]){seen[ny*sw+nx]=0;q.push([nx,ny])}}}if(n<10)continue;const w=maxX-minX,h=maxY-minY,aspect=w/Math.max(1,h),fill=n/Math.max(1,(w/step+1)*(h/step+1));if(w<14||w>sw*.5||h>sh*.2||aspect<1.35)continue;let score=.28*Math.min(1,w/(sw*.2))+.28*Math.min(1,aspect/3.5)+.18*Math.min(1,fill/.3);const cx=(minX+maxX)/2,cy=(minY+maxY)/2;if(hoopHint){const hx=(1-hoopHint.x/canvas.width)*sw,hy=hoopHint.y/canvas.height*sh,dist=Math.hypot(cx-hx,cy-hy);score+=.16*Math.max(0,1-dist/(sw*.22))}if(hoop){const hx=(1-hoop.x/canvas.width)*sw,hy=hoop.y/canvas.height*sh,dist=Math.hypot(cx-hx,cy-hy);score+=.22*Math.max(0,1-dist/(sw*.16))}comps.push({cx,cy,w,h,score})}comps.sort((a,b)=>b.score-a.score);return comps[0]||null}
function scanForRim(ts){if(!running||hoopLocked||ts-lastRimScan<260||canvas.width<2)return;lastRimScan=ts;try{const best=candidateFromImage();if(!best)return;const x=(best.cx/rimScanCanvas.width)*canvas.width,y=best.cy/rimScanCanvas.height*canvas.height;const rx=clamp((best.w/rimScanCanvas.width)*canvas.width*.5,28,canvas.width*.16),ry=clamp((best.h/rimScanCanvas.height)*canvas.height*.55,10,canvas.height*.07);if(!hoop){hoop=normalizeHoop({x,y,rx,ry});stableRimFrames=1}else{const dist=Math.hypot(x-hoop.x,y-hoop.y),maxDrift=canvas.width*.085;if(dist<maxDrift){hoop.x=hoop.x*.7+x*.3;hoop.y=hoop.y*.7+y*.3;hoop.rx=hoop.rx*.75+rx*.25;hoop.ry=hoop.ry*.75+ry*.25;stableRimFrames++}else stableRimFrames=Math.max(0,stableRimFrames-2)}rimCandidates.push({x,y,score:best.score});if(rimCandidates.length>24)rimCandidates.shift();const avgErr=rimCandidates.length?rimCandidates.reduce((a,p)=>a+Math.hypot(p.x-hoop.x,p.y-hoop.y),0)/rimCandidates.length:999;const consistency=1-clamp(avgErr/(canvas.width*.065),0,1);hoopConfidence=clamp(best.score*60+consistency*40,0,100);updateBadges();maybeLockRim()}catch(e){}}
function centerOf(pred){const [x,y,w,h]=pred.bbox;return{x:x+w/2,y:y+h/2,r:(w+h)/4,w,h,score:pred.score}}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function chooseBall(preds,now){const balls=preds.filter(p=>p.class==='sports ball'&&p.score>=.32).map(centerOf);if(!balls.length)return null;if(!ballTrack)return balls.sort((a,b)=>b.score-a.score)[0];const dt=Math.max(.05,(now-ballTrack.t)/1000),maxJump=Math.min(260,120+dt*900);let best=null,bestScore=-Infinity;for(const b of balls){const d=distance(b,ballTrack),jumpScore=Math.max(0,1-d/maxJump),sizeScore=1-Math.min(1,Math.abs(b.r-ballTrack.r)/Math.max(12,ballTrack.r)),score=.55*jumpScore+.25*sizeScore+.2*b.score;if(score>bestScore){bestScore=score;best=b}}return bestScore>.22?best:null}
function insideHoop(p){if(!hoop)return false;const dx=(p.x-hoop.x)/Math.max(hoop.rx,1),dy=(p.y-hoop.y)/Math.max(hoop.ry*1.8,1);return dx*dx+dy*dy<=1}
function trajectoryCross(prev,p){if(!hoop||!prev)return null;const y0=prev.y-hoop.y,y1=p.y-hoop.y;if(y0===y1)return null;if((y0<0&&y1>=0)||(y0>0&&y1<=0)){const t=-y0/(y1-y0);const x=prev.x+(p.x-prev.x)*t;return {x,y:hoop.y,inside:Math.abs(x-hoop.x)<=hoop.rx*1.05,t}}return null}
function resetShot(){shotState=null;ballTrail=[]}
function startShot(now,p,vx,vy){shotState={started:now,launchY:p.y,apexY:p.y,last:p,ascending:vy<0,downward:false,crossed:false,crossX:null,contact:false,peakTime:now};}
function classifyShot(now,p,vx,vy){if(!shotState)return;shotState.last=p;if(vy>45){shotState.downward=true;shotState.ascending=false}if(p.y<shotState.apexY){shotState.apexY=p.y;shotState.peakTime=now}const cross=trajectoryCross(ballTrack,p);if(cross&&!shotState.crossed){shotState.crossed=true;shotState.crossX=cross.x;shotState.crossInside=cross.inside;shotState.crossTime=now}if(shotState.crossed){const below=p.y>hoop.y+Math.max(hoop.ry*1.4,12);if(shotState.crossInside&&shotState.downward&&below&&now-shotState.crossTime>70){addShot(true,true);setStatus('🏀 <strong>MAKE detected automatically.</strong>');resetShot();return}if(now-shotState.crossTime>450){addShot(false,true);setStatus('❌ <strong>MISS detected automatically.</strong>');resetShot();return}}if(now-shotState.started>2400){addShot(false,true);setStatus('❌ <strong>MISS detected automatically.</strong>');resetShot()}}
function processBall(p){const now=performance.now();if(!p)return;if(ballTrack){const dt=Math.max(.05,(now-ballTrack.t)/1000);const vx=(p.x-ballTrack.x)/dt,vy=(p.y-ballTrack.y)/dt,speed=Math.hypot(vx,vy);ballTrail.push({...p,vx,vy,t:now});if(ballTrail.length>24)ballTrail.shift();if(!hoopLocked){if(!shotState&&vy<-140&&speed>180&&(!hoop||distance(p,hoop)<Math.max(hoop.rx*4,140)))startShot(now,p,vx,vy);if(shotState&&vy>45)shotState.downward=true;if(shotState&&shotState.downward&&now-shotState.started>650){recordWarmupAttempt();resetShot();return}if(shotState&&now-shotState.started>2600){recordWarmupAttempt();resetShot();return}}else if(hoop){const near=distance(p,hoop)<Math.max(hoop.rx*3.2,90);if(!shotState&&near&&vy<-120&&speed>180)startShot(now,p,vx,vy);if(shotState)classifyShot(now,p,vx,vy)}}ballTrack={...p,t:now,seq:frameSeq++}}
function invalidateBall(){if(ballTrack&&performance.now()-ballTrack.t>420){ballTrack=null;if(!shotState)ballTrail=[]}}
async function loadScript(src){return new Promise((resolve,reject)=>{const el=document.createElement('script');el.src=src;el.async=true;el.onload=resolve;el.onerror=()=>reject(new Error('Could not load AI library'));document.head.appendChild(el)})}
function rfPredictionBox(p){
  const b=p.bbox||p.box||p; const x=Number(b.x),y=Number(b.y),w=Number(b.width),h=Number(b.height);
  if(!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(w)||!Number.isFinite(h))return null;
  return {x,y,w,h,c:Number(p.confidence||p.score||0),cls:String(p.class||p.label||'').toLowerCase()};
}
function applyDedicatedDetections(preds){
  const all=(preds||[]).map(rfPredictionBox).filter(Boolean);
  const rims=all.filter(p=>p.c>=.45&&(p.cls==='rim'||p.cls.includes('rim')));
  const balls=all.filter(p=>p.c>=.32&&(p.cls==='basketball'||p.cls==='sports ball'||p.cls.includes('basketball')||p.cls.includes('sports ball')));
  let rimSeen=false;
  if(rims.length){
    rimSeen=true;rims.sort((a,b)=>b.c-a.c);const p=rims[0],x=p.x+p.w/2,y=p.y+p.h/2,rx=Math.max(18,p.w*.5),ry=Math.max(8,p.h*.5);
    if(!hoop){hoop=normalizeHoop({x,y,rx,ry});stableRimFrames=1}else{const d=Math.hypot(x-hoop.x,y-hoop.y),gate=Math.max(canvas.width*.10,hoop.rx*2.6);if(d<gate){hoop.x=hoop.x*.72+x*.28;hoop.y=hoop.y*.72+y*.28;hoop.rx=hoop.rx*.78+rx*.22;hoop.ry=hoop.ry*.78+ry*.22;stableRimFrames=Math.min(80,stableRimFrames+2)}else stableRimFrames=Math.max(0,stableRimFrames-2)}
    rimCandidates.push({x,y,score:p.c});if(rimCandidates.length>30)rimCandidates.shift();const recent=rimCandidates.slice(-12),avgErr=recent.length?recent.reduce((a,q)=>a+Math.hypot(q.x-hoop.x,q.y-hoop.y),0)/recent.length:999,consistency=1-clamp(avgErr/(canvas.width*.035),0,1);hoopConfidence=clamp(p.c*65+consistency*35,0,100);updateBadges();maybeLockRim();
  }
  if(balls.length){const candidates=balls.map(p=>({bbox:[p.x,p.y,p.w,p.h],score:p.c,class:'sports ball'}));const chosen=chooseBall(candidates,performance.now());if(chosen)processBall(chosen)}
  return rimSeen;
}
async function loadDedicatedDetector(){
  if(!rfKey||rfLoading||rfReady)return;
  rfLoading=true;rfStatus.textContent='Dedicated detector: loading model…';updateBadges();
  try{
    const mod=await import('https://cdn.jsdelivr.net/npm/inferencejs@1.3.0/+esm');
    RFInferenceEngine=mod.InferenceEngine; RFCVImage=mod.CVImage;
    rfEngine=new RFInferenceEngine();
    rfWorker=await rfEngine.startWorker(RF_MODEL,Number(RF_VERSION),rfKey,{scoreThreshold:.45,iouThreshold:.45,maxNumBoxes:10});
    rfReady=true;rfStatus.textContent='Dedicated detector: ready';
  }catch(e){rfReady=false;rfWorker=null;rfStatus.textContent='Dedicated detector: failed to load; using fallback';}
  finally{rfLoading=false;updateBadges()}
}
async function inferDedicated(){
  if(!rfReady||!rfEngine||!rfWorker||video.readyState<2)return false;
  try{const img=new RFCVImage(video);const preds=await rfEngine.infer(rfWorker,img,{scoreThreshold:.35,iouThreshold:.45,maxNumBoxes:12});return applyDedicatedDetections(preds)}catch(e){rfStatus.textContent='Dedicated detector error; fallback active';rfReady=false;return false}
}
async function inferLoop(ts){
  if(!running)return;invalidateBall();let dedicatedUsed=false;
  if(rfReady&&!inferBusy&&ts-lastRimScan>220){inferBusy=true;lastRimScan=ts;try{dedicatedUsed=await inferDedicated()}finally{inferBusy=false}}
  if(!dedicatedUsed&&!hoopLocked)scanForRim(ts);
  if(!rfReady&&!inferBusy&&model&&video.readyState>=2&&ts-lastInfer>150){inferBusy=true;lastInfer=ts;try{const preds=await model.detect(video,8,.32);const ball=chooseBall(preds,performance.now());if(ball)processBall(ball)}catch(e){}finally{inferBusy=false}}
  requestAnimationFrame(inferLoop)
}
async function loadAI(){if(aiLoading||aiReady)return;aiLoading=true;updateBadges();try{await loadScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.20.0/dist/tf.min.js');await loadScript('https://cdn.jsdelivr.net/npm/@tensorflow-models/coco-ssd@2.2.3/dist/coco-ssd.min.js');await tf.ready();if(tf.getBackend()!=='webgl')try{await tf.setBackend('webgl');await tf.ready()}catch(e){}model=await cocoSsd.load({base:'lite_mobilenet_v2'});aiReady=true;badge.textContent='AI ready';live.textContent='AI tracking';warmupStatus()}catch(e){badge.textContent='AI error';setStatus('<strong>AI could not load.</strong> Check your internet connection and reload.');}finally{aiLoading=false;updateBadges()}}
async function startCamera(){if(!navigator.mediaDevices?.getUserMedia){setStatus('<strong>Camera unavailable.</strong> Use HTTPS or localhost.');return}try{resetTrackingState();stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30}},audio:false});video.srcObject=stream;await video.play();resize();loadHoop();rfKey=localStorage.getItem('rf_publishable_key')||rfKey;rfKeyEl.value=rfKey;running=true;startBtn.textContent='Stop Camera';live.textContent='Camera ready';setStatus('<strong>Camera is on.</strong> AI is loading in the background. Shoot normally; the rim detector will use warm-up attempts to confirm the hoop.');draw();requestAnimationFrame(inferLoop);loadAI();loadDedicatedDetector()}catch(e){setStatus('<strong>Camera failed:</strong> '+e.message+'<br>Use HTTPS (or localhost) and allow camera permission.')}}
function stopCamera(){running=false;stream?.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;live.textContent='Camera off';startBtn.textContent='Start Camera + AI';resetTrackingState();updateBadges()}
startBtn.onclick=()=>running?stopCamera():startCamera();
$('manualMake').onclick=()=>addShot(true,false);$('manualMiss').onclick=()=>addShot(false,false);
rfKeyEl.value=rfKey;
rfSave.onclick=()=>{rfKey=rfKeyEl.value.trim();if(rfKey){localStorage.setItem('rf_publishable_key',rfKey);loadDedicatedDetector()}else{localStorage.removeItem('rf_publishable_key');rfKey='';rfReady=false;rfWorker=null;rfStatus.textContent='Dedicated detector: not configured'}};
$('reset').onclick=()=>{shots=[];renderStats();resetTrackingState();if(running){setStatus('🔥 Reset. Shoot normally and the AI will search for the hoop again.')}else setStatus('Start the camera and shoot normally. The AI will search for the rim during warm-up.')};
function hoopPointFromPointer(e){const r=canvas.getBoundingClientRect(),sx=clamp((e.clientX-r.left)/r.width,0,1),sy=clamp((e.clientY-r.top)/r.height,0,1);return{x:(1-sx)*canvas.width,y:sy*canvas.height}}
function moveHoop(e){const p=hoopPointFromPointer(e);hoop=normalizeHoop({x:p.x,y:p.y,rx:canvas.width*.07,ry:canvas.height*.025});hoopConfidence=100;stableRimFrames=20}
calBtn.onclick=()=>{if(!running){setStatus('Start the camera first.');return}calibrating=true;hoopLocked=false;live.textContent='Position hoop';canvas.style.cursor='grab';setStatus('<strong>Drag the marker onto the center of the rim.</strong> Release to lock the manual position. Automatic detection will use it as a trusted fallback.')};
canvas.addEventListener('pointerdown',e=>{if(!calibrating)return;e.preventDefault();draggingHoop=true;canvas.setPointerCapture?.(e.pointerId);moveHoop(e);canvas.style.cursor='grabbing'});canvas.addEventListener('pointermove',e=>{if(draggingHoop){e.preventDefault();moveHoop(e)}});canvas.addEventListener('pointerup',e=>{if(!draggingHoop)return;e.preventDefault();moveHoop(e);draggingHoop=false;calibrating=false;hoopLocked=true;saveHoop();live.textContent='AI tracking';canvas.style.cursor='grab';setStatus('🎯 <strong>Manual rim locked.</strong> The AI will now track the ball and classify shots.');updateBadges()});canvas.addEventListener('pointercancel',()=>{draggingHoop=false;calibrating=false;canvas.style.cursor='grab'});
renderStats();updateBadges();
