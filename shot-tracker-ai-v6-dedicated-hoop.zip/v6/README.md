# Shot Tracker AI v4

Mobile-first basketball shot tracker with on-device camera processing.

## What v4 fixes
- Removes the broken `WARMUPS` runtime reference.
- Centralizes tracking reset so old ball/rim state cannot leak between sessions.
- Tracks one basketball across detections instead of always taking the highest-confidence ball.
- Invalidates stale ball positions after detector dropouts.
- Uses a trajectory crossing calculation so a ball can cross the rim plane between detector frames.
- Uses dynamic rim width/height instead of fixed hoop dimensions.
- Stabilizes rim candidates across frames and uses previous-session position only as a hint.
- Requires repeated rim evidence plus warm-up ball trajectories before automatic rim lock.
- Supports a 3-shot minimum, 5-shot confirmation target, and up to 12 attempts if confidence is poor.
- Uses an explicit shot state with launch, ascent, descent, rim crossing, and result handling.
- Separates camera/display resolution from lower-cost rim scanning.
- Attempts WebGL for TensorFlow.js when available.
- Handles camera start/stop/reset cleanly.
- Keeps manual hoop placement as a fallback rather than the normal workflow.
- Shows rim confidence/lock state in the camera UI.

## Important
This is still a browser CV prototype. The rim detector is a lightweight heuristic, not a separately trained basketball-hoop model. Real-world accuracy must be validated with actual phone footage in different gyms, lighting, distances, and angles.

Camera access normally requires HTTPS or localhost.


## v5 dedicated detector
Optional browser-side integration with Roboflow inferencejs using the public `basketball-1zhpe-8qwvy/1` YOLOLite Nano model. The model detects `rim`, `basketball`, and `sports ball`. A Roboflow publishable key must be supplied by the app user; no secret API key is embedded. The existing local detector remains as fallback.
